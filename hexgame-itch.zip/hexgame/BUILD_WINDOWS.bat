@echo off
title لعبة الخلية — Build Script
color 0A

:: ── Move to the folder where this .bat lives ──────────
cd /d "%~dp0"

echo.
echo  ============================================
echo    لعبة الخلية  —  EXE Builder for itch.io
echo  ============================================
echo.

:: Check Node.js
node --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo  [ERROR] Node.js not found!
    echo.
    echo  Please install Node.js from: https://nodejs.org
    echo  Then run this script again.
    echo.
    pause
    exit /b 1
)

echo  [OK] Node.js found: 
node --version
echo.

:: Install dependencies
echo  Installing Electron + builder...
echo  (This may take a few minutes on first run)
echo.
call npm install
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  [ERROR] npm install failed. Check your internet connection.
    pause
    exit /b 1
)

echo.
echo  Building Windows EXE...
echo.
call npm run build:win
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  [ERROR] Build failed. See output above.
    pause
    exit /b 1
)

echo.
color 0A
echo  ============================================
echo    BUILD COMPLETE!
echo  ============================================
echo.
echo  Your files are in the  dist\  folder:
echo.
echo    Installer:  dist\لعبة الخلية Setup 1.0.0.exe
echo    Portable:   dist\لعبة الخلية 1.0.0.exe
echo.
echo  For itch.io upload either file.
echo  Set "Kind of project" to Windows executable.
echo.
pause
